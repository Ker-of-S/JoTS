#import "modules/colors.typ": *

// Main function
#let jots-article(
  title: "",
  subtitle: none,
  running-title: "Short Running Title",
  authors: (),
  abstract: none,
  keywords: (),
  twocolumn: true,
  body
) = {
  
  // PDF config & metadata
  set document(title: title, author: authors.map(a => a.name))
  
  // Geometry
  set page(
    paper: "a4",
    margin: 24mm,
    header: context {
      let i = counter(page).get().first()
      
      if i == 1 { return none }
      
      if calc.even(i) {
        grid(columns: (1fr, 1fr), align(left)[#i], align(right)[])
      } else {
        grid(columns: (1fr, 1fr), align(left)[], align(right)[#i])
      }
    },
    footer: [
      #set text(size: 9pt, fill: rgb("B3B3B3"))
      #align(center)[Journal of Terminal Sciences --- #running-title]
      #line(length: 100%, stroke: 0.2pt)
    ]
  )

  // Typ.
  set text(font: "New Computer Modern", size: 11pt)
  show link: set text(fill: link-color)

  // Title style
  show heading.where(level: 1): it => block(below: 1em)[
    #set text(fill: primary-blue, size: 14pt, weight: "bold")
    #it
    #line(length: 100%, stroke: 0.5pt + primary-blue)
  ]

  // ===================
  // TITLEBLOCK
  // ===================
  align(center)[
    #v(1.4cm)
    #text(fill: luma(120), size: 9pt, style: "italic")["Journal of Terminal Sciences"]
    
    #text(fill: primary-blue, size: 18pt, weight: "bold", title)
    
    #if subtitle != none [
      #text(fill: dark-gray, size: 14pt, subtitle)
    ]
    
    #grid(
      columns: (1fr, 1fr), // Two column auth, if u want more, just add ", 1fr"
      row-gutter: 1em,
      ..authors.map(author => align(center)[
        *#author.name* \
        #text(size: 9pt, style: "italic", author.affiliation) \
        #link("mailto:" + author.email)[#text(size: 9pt, author.email)]
      ])
    )
    
    #line(length: 100%, stroke: 0.4pt)
    #v(0.4cm)
    
    // Abstract y Keywords
    #if abstract != none [
      #align(center)[#block(width: 88%)[
        *#text(fill: primary-blue, "Abstract.")* #abstract
      ]
      #v(0.4cm)]
    ]
    
    #if keywords != () [
      #align(center)[#block(width: 88%)[
        *#text(fill: primary-blue, "Keywords:")* #emph(keywords.join(", "))
      ]]
    ]
    #v(0.6cm)
  ]

  show raw.where(block: true): it => block(
    fill: code-bg,
    stroke: 0.4pt + luma(180),
    inset: (x: 10pt, y: 8pt),
    radius: 2pt,
    width: 100%,
    text(size: 9pt, it)
  )
  show figure.caption: it => block(align(left)[
    #text(fill: primary-blue, weight: "bold")[#it.supplement #it.counter.display().]
    #text(size: 10pt, it.body)
  ])
  show figure.where(kind: table): set figure.caption(position: top)

  set text(hyphenate: true)
  set par(justify: true)
  
  if twocolumn {
    columns(2, gutter: 15pt)[
      #body
    ]
  } else {
    body
  }
}