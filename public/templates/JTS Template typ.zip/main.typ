#import "template.typ": jots-article
#import "modules/math.typ": *
#import "modules/boxes.typ": *

#set heading(numbering: "1.")

#show: jots-article.with(
  title: "Article Title Blah Blah Blah",
  subtitle: "Subtitle blah blah blah",
  running-title: "JoTS Template Showcase",
  authors: (
    (
      name: "Author 1 Complete Name", 
      affiliation: "affiliation", 
      email: "author@mail.mx"
    ),
    (
      name: "Author 2 Complete Name", 
      affiliation: "affiliation", 
      email: "author@mail.mx"
    ),
    (
      name: "Author 3 Complete Name", 
      affiliation: "affiliation", 
      email: "author@mail.mx"
    ),
    (
      name: "Author 4 Complete Name", 
      affiliation: "affiliation", 
      email: "author@mail.mx"
    )
  ),
  abstract: [#lorem(60)],
  keywords: ("kw", "kerd", "keyord", "keyword", "yep")
)

= Section

Welcome to the template showcase. This section demonstrates standard text formatting, such as #hl[highlighted text], #ie, and #eg. #lorem(20) 

#figure(
  placeholder(width: 80%, height: 100pt, label: "Placeholder cf"),
  caption: [#lorem(6)]
)

== Subsection
#lorem(40)

= Mathematical Environments <math-section>

#lorem(30):

$ E[(g(t) - mu)^3] != 0 $

#lorem(19)

#defbox("definition title")[
  #lorem(30)
]

Custom operators:

$ argmax_(x in R^n) ( inner(x, A x) ) / (norm(x)^2) $

= Custom Environments and Callouts

The `modules/boxes.typ` file provides a rich set of callout boxes designed for technical and narrative documentation. 

#infobox[
  *Note:* #lorem(20)
]

#warningbox[
  #lorem(20)
]

#dangerbox[
  #fix("Write something here") \
  #lorem(20)
]

= Code and Terminal Outputs

#lorem(20). Use the `termbox` for shell commands:

#termbox[
cargo build --target wasm32-unknown-unknown --release
wasm-bindgen --out-dir ./pkg --target web target/wasm32-unknown-unknown/release/mirai_engine.wasm
]

#lorem(20). As shown in @math-section, cross-referencing is #lorem(10)


#lorem(40)

#figure(
  caption: [#lorem(30)],
  ```python
  import numpy as np
  import bpy # Blender Python API

  def generate_orbital(n, l, m):
      """Calc density prob"""
      radius = np.linspace(0, 10, 100)
      # Simplified sim
      return np.exp(-radius / n) * (radius ** l)```
)

= Long Tables

#lorem(30) @table.

#figure(
  placement: top,    // Float to top
  scope: "parent",   // Temp col break
  caption: [#lorem(20)],
  table(
    columns: (1fr, auto, auto, auto),
    stroke: none,
    align: (left, center, center, center),
    
    table.hline(stroke: 1pt), // \toprule
    [*Column 1*], [*Column 2*], [*Column 3*], [*Column 4*],
    table.hline(stroke: 0.5pt), // \midrule
    
    [row 1], [120.4], [115.2], [$pm 2.4$],
    [row 2], [45.1], [42.8], [$pm 0.8$],
    [row 3], [305.9], [290.1], [$pm 15.6$],
    
    table.hline(stroke: 1pt)  // \bottomrule
  )
) <table>

= Theorem-like env.

#lorem(20)

#theorem[
#lorem(20)
]
#theorem[
#lorem(20)
]
#definition[
#lorem(20)
]

#lemma[
#lorem(20)
]

#corollary[
#lorem(20)
]

#proposition[
#lorem(20)
]

#oraculum[
#lorem(20)
]

#lorem(60)

#remark[
#lorem(20)
]
#theorem[
#lorem(20)
]
#definition[
#lorem(20)
]

#remark[
#lorem(20)
]

#corollary[
#lorem(20)
]

#proposition[
#lorem(20)
]

#oraculum[
#lorem(10)
]