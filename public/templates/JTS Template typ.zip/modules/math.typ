#import "colors.typ": *

// Math shortcuts (Typst native equivalents)
#let Prob = math.bb("P")
#let eps = math.epsilon
#let inner(a, b) = $chevron.l a, b chevron.r$
#let pm = sym.plus.minus

// Custom operators
#let diag = math.op("diag")
#let tr = math.op("tr")
#let rank = math.op("rank")
#let argmin = math.op("arg min", limits: true)
#let argmax = math.op("arg max", limits: true)

// Text macros
#let ie = emph("i.e.")
#let eg = emph("e.g.")
#let etal = emph("et al.")

// Revision tools
#let hl(content) = text(fill: accent-orange, weight: "bold", content)
#let fix(content) = text(fill: accent-red, weight: "bold", "[FIX: " + content + "]")

// Thm env.
#let math-env(title, id, body, is-emph: true) = context {
  let h-counter = counter(heading).get()
  
  let sec-num = if h-counter.len() > 0 { h-counter.first() } else { 0 }
  
  let c = counter(id + "-" + str(sec-num))
  c.step()

  let content = if is-emph { emph(body) } else { body }
  
  block(width: 100%, breakable: true, [
    *#title #sec-num.#c.display().* #content
  ])
}

#let definition(body) = math-env("Definition", "m", body, is-emph: false)
#let theorem(body) = math-env("Theorem", "m", body)
#let lemma(body) = math-env("Lemma", "m", body)
#let corollary(body) = math-env("Corollary", "m", body)
#let proposition(body) = math-env("Proposition", "m", body)
#let oraculum(body) = math-env("Oraculum", "m", body)
#let remark(body) = math-env("Remark", "m", body, is-emph: false)

$RR$