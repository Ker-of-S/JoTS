#import "colors.typ": *

// Boxes base
#let callout-box(title, body, color: primary-blue) = {
  block(
    fill: color.lighten(92%),
    stroke: color,
    width: 100%,
    inset: 0pt,
    radius: 0pt,
    breakable: true,
    [
      #block(
        fill: color,
        inset: (x: 6pt, y: 4pt),
        text(fill: white, weight: "bold", size: 9pt)[#title]
      )
      #block(inset: (x: 10pt, y: 6pt), body)
    ]
  )
}

// Boxes
#let infobox(body) = callout-box("Note", body, color: note-col)
#let warningbox(body) = callout-box("Warning", body, color: accent-orange)
#let dangerbox(body) = callout-box("Danger", body, color: danger-col)
#let defbox(title, body) = callout-box("Definition: " + title, body, color: primary-blue)

// Terminal box
#let termbox(body) = block(
  fill: dark-gray,
  stroke: dark-gray.darken(20%),
  width: 100%,
  [
    #block(inset: (x: 8pt, y: 4pt), text(fill: accent-cyan.lighten(20%), weight: "bold", font: "Fira Code", size: 9pt)[\$ shell])
    #block(inset: (x: 10pt, bottom: 8pt, top: 0pt), text(fill: white, font: "Fira Code", size: 9pt, body))
  ]
)

// Placeholder
#let placeholder(width: 100%, height: 150pt, label: "Image Placeholder") = {
  rect(
    width: width,
    height: height,
    stroke: (paint: luma(150), thickness: 1pt, dash: "dashed"),
    fill: luma(245),
    align(center + horizon, text(fill: luma(100), weight: "bold")[#label])
  )
}